<?php
    session_start();

    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = "devbunch_task";
    $conn = mysqli_connect($servername, $username, $password, "$dbname");
    if (!$conn) {
        die('Could not Connect MySql Server:' . mysql_error());
    }

    $_SESSION["company_name"] = "DevBunch";
?>