<?php
    include("conn/conn.php");

    if(empty($_GET['id'])){
        header("Location: index.php");
        die;
    }

    $id = $_GET['id'];

    $select_user = $conn->query("SELECT * FROM users WHERE id = '$id'");
    $row_user = mysqli_fetch_assoc($select_user);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Message</title>

    <?php include ('includes/head.php')?>
</head>


<body>
    <div class="container-fluid text-center">
        <div class="alert alert-success mt-5" role="alert">
            <h4 class="alert-heading">Hi <?php echo $row_user['name'] ?></h4>
            <p>
                Your account has been registered successfully. Please check your email and activate your account first. Thank You
            </p>
            <hr>
            <p class="mb-0" style="font-size: 20px;font-weight: bold;">
                <a href="index.php">Go Back</a>
            </p>
        </div>
    </div>
</body>
</html>